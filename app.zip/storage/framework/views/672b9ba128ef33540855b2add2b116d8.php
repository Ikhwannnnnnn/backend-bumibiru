<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="icon" href="<?php echo e(asset('img/gurucoding_icon.png')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <meta name="keywords" content="gurucoding">
    <meta name="description" content="Welcome to Dashboard GuruCoding">
    <meta name="author" content="GuruCoding">
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        <?php if(Session::has('message')): ?>
        var type = "<?php echo e(Session::get('alert-type', 'info')); ?>"
        switch (type) {
            case 'info':
                toastr.info("<?php echo e(Session::get('message')); ?>");
                break;
            case 'success':
                toastr.success("<?php echo e(Session::get('message')); ?>");
                break;
            case 'warning':
                toastr.warning("<?php echo e(Session::get('message')); ?>");
                break;
            case 'error':
                toastr.error("<?php echo e(Session::get('message')); ?>");
                break;
        }
        <?php endif; ?>
    </script>
</body>

</html><?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Univ\Semester 6\SIB\capstone\backend_gurucoding\resources\views/auth/authApp.blade.php ENDPATH**/ ?>