
<?php $__env->startSection('title', 'GuruCoding | Dashboard'); ?>
<?php $__env->startSection('keywords', 'Sistem Pengelolaan Mentor GuruCoding, GuruCoding, Sistem Pengelolaan, Website, gurucoding'); ?>
<?php $__env->startSection('description', 'Dashboard Mentor GuruCoding'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 text-center">
        <h2 class="h3 mb-4">Detail Mentor GuruCoding</h2>
    </div>
</div>
<style>
    #map { height: 500px; }
</style>
<div class="row">
    <div class="card col-lg-12" style="color: black">
        <div class="card-header">Informasi Mentor</div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="name">Nama Lengkap</label>
                    <p id="name" class="form-control-plaintext"><?php echo e($data->name); ?></p>
                </div>
                <div class="form-group col-md-6">
                    <label for="email">Email</label>
                    <p id="email" class="form-control-plaintext"><?php echo e(session('user.email')); ?></p>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="phone">No. Handphone</label>
                    <p id="phone" class="form-control-plaintext"><?php echo e($data->phone); ?></p>
                </div>
                <div class="form-group col-md-6">
                    <label for="skills">Keterampilan</label>
                    <p id="skills" class="form-control-plaintext"><?php echo e($data->skills); ?></p>
                </div>
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <p id="description" class="form-control-plaintext"><?php echo e($data->description); ?></p>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="image">Foto</label>
                    <div>
                        <?php if($data->image && $data->image != 'img_empty.gif'): ?>
                            <img src="<?php echo e(asset('storage/mentor/img/'.$data->image)); ?>" class="img-thumbnail" style="max-height: 250px; height: auto;">
                        <?php else: ?>
                            <img src="<?php echo e(asset('img/img_empty.gif')); ?>" class="img-thumbnail" style="max-height: 250px; height: auto;">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group col-md-6">
                    <label for="cv">CV</label>
                    <div>
                        <?php if($data->cv): ?>
                            <a href="<?php echo e(asset('storage/mentor/cv/'.$data->cv)); ?>" target="_blank">View PDF</a>
                        <?php else: ?>
                            <p class="form-control-plaintext">No CV uploaded</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="alamat">Alamat</label>
                <p id="alamat" class="form-control-plaintext"><?php echo e($data->alamat); ?></p>
            </div>
            <div id="map" class="form-group"></div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="latitude">Latitude</label>
                    <p id="latitude" class="form-control-plaintext"><?php echo e($data->latitude); ?></p>
                </div>
                <div class="form-group col-md-6">
                    <label for="longitude">Longitude</label>
                    <p id="longitude" class="form-control-plaintext"><?php echo e($data->longitude); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    var map = L.map('map').setView([<?php echo e($data->latitude); ?>, <?php echo e($data->longitude); ?>], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    var marker = L.marker([<?php echo e($data->latitude); ?>, <?php echo e($data->longitude); ?>]).addTo(map);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Univ\Semester 6\SIB\capstone\backend_gurucoding\resources\views/detailMentor.blade.php ENDPATH**/ ?>