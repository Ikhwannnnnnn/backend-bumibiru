
<?php $__env->startSection('title', 'GuruCoding | Dashboard'); ?>
<?php $__env->startSection('keywords', 'Sistem Pengelolaan GuruCoding, GuruCoding, Sistem Pengelolaan, Website, gurucoding, admin'); ?>
<?php $__env->startSection('description', 'Dashboard Admin GuruCoding'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <h2>List Mentor</h2>
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="dataTable" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Email</th>
                                <th>No. Handphone</th>
                                <th>Keterampilan</th>
                                <th>Alamat</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $mentors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($mentor->name); ?></td>
                                    <td><?php echo e($mentor->user->email); ?></td>
                                    <td><?php echo e($mentor->phone); ?></td>
                                    <td><?php echo e($mentor->skills); ?></td>
                                    <td><?php echo e(substr($mentor->alamat, 0, 50)); ?>...</td>
                                    <td>
                                        <a href="<?php echo e(route('detailMentor', encrypt($mentor->id))); ?>" class="btn btn-info btn-sm">Detail</a>
                                        <form action="<?php echo e(route('destroyMentor',encrypt($mentor->id))); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus mentor ini?')">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Univ\Semester 6\SIB\capstone\backend_gurucoding\resources\views/dashboard_admin.blade.php ENDPATH**/ ?>