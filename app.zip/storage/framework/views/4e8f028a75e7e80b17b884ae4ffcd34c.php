<?php
    $route= Route::current()->getName();
?>

<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('dashboard')); ?>">
        <div class="sidebar-brand-icon">
            <img style="width: 50px" src="<?php echo e(asset('img/Logo_Paroki_Transparan.png')); ?>" alt="">
        </div>
        <div class="sidebar-brand-text mx-2">Paroki Asam Besar</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item <?php echo e($route=='dashboard' ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
            <i class='bx bxs-dashboard'></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Menu
    </div>

    <!-- Nav Item -->
    <li class="nav-item <?php echo e($route=='user' ? 'active' : ''); ?>">
        <a class="nav-link" href="#">
            <i class='bx bx-user'></i>
            <span>Kelola Mentor</span></a>
    </li>

    <hr class="sidebar-divider d-none d-md-block">

    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul><?php /**PATH C:\Users\yohke\OneDrive - Universitas Atma Jaya Yogyakarta\Univ\Semester 6\SIB\capstone\backend_gurucoding\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>