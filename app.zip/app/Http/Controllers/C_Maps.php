<?php

namespace App\Http\Controllers;

use App\Models\Mentor;
use Illuminate\Http\Request;

class C_Maps extends Controller
{
    public function index()
    {
        $data = Mentor::where('status', 'publish')->get();
        return view('maps', compact('data'));
    }

    public function search(Request $request)
    {
        $query = $request->input('search');
        $data = Mentor::where('status', 'publish')
            ->where('skills', 'like', '%' . $query . '%')
            ->get();
        return response()->json($data);
    }
}
